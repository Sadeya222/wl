import re
from typing import Dict, Iterable, Optional, Tuple

from src.schema import format_price

# Keywords distinguishing digital deals (require clipping/activation)
DIGITAL_DEAL_RE = re.compile(
    r"\b(?:clip\s*coupon|digital\s*coupon|clipped\s*coupon|activate\s*offer|save\s*offer)\b",
    re.IGNORECASE,
)

# Cashback / Walmart Cash / manufacturer rebates must NOT be treated as immediate digital price reductions
CASHBACK_IGNORE_RE = re.compile(
    r"\b(?:walmart\s*cash|cash\s*back|cashback|manufacturer\s*offer|ibotta|rebate)\b",
    re.IGNORECASE,
)

# Volume deals (no clipping/activation required)
VOLUME_DEAL_RE = re.compile(
    r"(?:\b\d+\s+for\s+\$?\d+(?:\.\d{1,2})?\b|"
    r"\bbuy\s+\d+\s*,?\s*get\s+\d+\s+(?:free|\d+%\s*off)\b|"
    r"\bmix\s*(?:or|&|and)?\s*match\b|"
    r"\bsave\s+\$?\d+(?:\.\d{1,2})?\s+when\s+you\s+buy\s+\d+\b|"
    r"\bmust\s+buy\s+\d+\b)",
    re.IGNORECASE,
)

BOGO_RE = re.compile(r"\bbuy\s+\d+\s*,?\s*get\s+\d+\s+free\b", re.IGNORECASE)

# Extract explicitly displayed promo price in a deal string (e.g. "$3.99 each", "2 for $5.00")
EXPLICIT_EACH_PRICE_RE = re.compile(r"\$(\d+(?:\.\d{1,2})?)\s*(?:each|ea|/ea)\b", re.IGNORECASE)
EXPLICIT_MULTI_FOR_PRICE_RE = re.compile(r"\b\d+\s+for\s+\$(\d+(?:\.\d{1,2})?)\b", re.IGNORECASE)

# PPM pattern e.g. "$0.25/oz", "$0.18/fl oz", "$3.99/lb", "$0.50/ct", "18.4¢/oz"
PPM_RE = re.compile(
    r"((?:\$\d+(?:\.\d{1,4})?|\d+(?:\.\d{1,2})?¢)\s*/\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)?)",
    re.IGNORECASE,
)

# Weight/size extraction fallback from product title
WEIGHT_RE = re.compile(
    r"(\b\d+(?:\.\d+)?\s*(?:fl\.?\s*oz|oz|lb|lbs|g|kg|ml|l|ct|count|pk|pack|qt|gal|pt|rolls?|sheets?)\b)",
    re.IGNORECASE,
)


def parse_ppm(raw_ppm: str) -> str:
    """Return Walmart's displayed PPM verbatim with unit, or '' if missing."""
    if not raw_ppm:
        return ""
    text = " ".join(raw_ppm.split())
    match = PPM_RE.search(text)
    if match:
        return match.group(1).strip()
    return ""


def extract_weight(explicit_weight: str, title: str) -> str:
    """Use explicit weight field if present; otherwise extract measurement from title."""
    if explicit_weight and explicit_weight.strip():
        return explicit_weight.strip()
    if not title:
        return ""
    match = WEIGHT_RE.search(title)
    return match.group(1).strip() if match else ""


def parse_deals(promo_texts: Iterable[str]) -> Dict[str, str]:
    """
    Separate volume deals from digital deals without calculating missing prices.
    - Never invent a price for BOGO without an explicit price.
    - Never calculate a final price from 'Save $1' or '20% off'.
    - Ignore Walmart Cash / cashback / manufacturer offers as digital reductions.
    """
    volume_descs = []
    volume_price = ""
    digital_descs = []
    digital_price = ""

    for raw in promo_texts:
        text = " ".join((raw or "").split())
        if not text:
            continue

        if CASHBACK_IGNORE_RE.search(text) and not DIGITAL_DEAL_RE.search(text):
            continue

        if DIGITAL_DEAL_RE.search(text):
            if text not in digital_descs:
                digital_descs.append(text)
            if not digital_price:
                each_match = EXPLICIT_EACH_PRICE_RE.search(text)
                if each_match:
                    digital_price = format_price(each_match.group(1))
        elif VOLUME_DEAL_RE.search(text):
            if text not in volume_descs:
                volume_descs.append(text)
            if not volume_price and not BOGO_RE.search(text):
                each_match = EXPLICIT_EACH_PRICE_RE.search(text)
                multi_match = EXPLICIT_MULTI_FOR_PRICE_RE.search(text)
                if each_match:
                    volume_price = format_price(each_match.group(1))
                elif multi_match:
                    volume_price = format_price(multi_match.group(1))

    return {
        "volume_deals_description": " | ".join(volume_descs),
        "volume_deals_price": volume_price,
        "digital_deals_description": " | ".join(digital_descs),
        "digital_deals_price": digital_price,
    }
