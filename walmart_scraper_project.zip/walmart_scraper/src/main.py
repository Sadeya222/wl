import argparse
import asyncio
import logging
import sys
import time
from datetime import datetime
from pathlib import Path

from src.checkpoint import CheckpointManager
from src.config_loader import BASE_DIR, load_categories, load_locations, load_settings
from src.validator import RunValidator
from src.walmart_scraper import WalmartScraper


def setup_logging(log_level: str) -> None:
    log_dir = BASE_DIR / "output" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"scraper_{ts}.log"

    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )


async def run_for_location(
    zipcode: str, resume: bool, max_records: int | None
) -> int:
    settings = load_settings()
    setup_logging(settings.log_level)
    logger = logging.getLogger("main")

    locations = load_locations()
    loc = next((l for l in locations if l.zipcode == zipcode), None)
    if not loc:
        logger.error("Zipcode %s not found in config/locations.json", zipcode)
        return 1

    categories = load_categories()
    if not categories:
        logger.error("No Walmart categories found in config/Walmart_Category_URLs.csv")
        return 1

    checkpoint = CheckpointManager(BASE_DIR, loc.zipcode)
    scraper = WalmartScraper(
        settings=settings,
        location=loc,
        checkpoint=checkpoint,
        max_records=max_records,
    )

    start = time.monotonic()
    try:
        await scraper.run(categories=categories, resume=resume)
    except Exception as exc:
        logger.exception("Scraper run interrupted or failed: %s", exc)
        checkpoint.save()
    runtime = time.monotonic() - start

    validator = RunValidator(
        base_dir=BASE_DIR,
        zipcode=loc.zipcode,
        target_min_records=settings.target_min_records,
    )
    passed, report = validator.validate_and_publish(checkpoint, runtime_seconds=runtime)

    logger.info(
        "Run finished | passed=%s | unique_records=%d | duplicates_prevented=%d | runtime=%.1fs",
        passed,
        report["total_unique_records"],
        report["duplicates_prevented"],
        runtime,
    )
    if not passed:
        logger.error("Validation issues: %s", report["issues"])
        return 2
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Production Walmart Local Scraper")
    parser.add_argument("--zipcode", default="75201", help="Target store ZIP from config/locations.json")
    parser.add_argument("--resume", action="store_true", help="Resume from last saved checkpoint")
    parser.add_argument("--max-records", type=int, default=None, help="Optional cap for demo runs (e.g. 600)")
    args = parser.parse_args()

    exit_code = asyncio.run(
        run_for_location(zipcode=args.zipcode, resume=args.resume, max_records=args.max_records)
    )
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
