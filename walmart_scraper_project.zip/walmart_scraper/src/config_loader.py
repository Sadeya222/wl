import csv
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent.parent


@dataclass
class RuntimeSettings:
    headless: bool = True
    min_delay_sec: float = 1.8
    max_delay_sec: float = 4.2
    max_retries: int = 3
    request_timeout_ms: int = 45000
    target_min_records: int = 500
    max_consecutive_empty_pages: int = 2
    log_level: str = "INFO"
    proxy_server: str = ""
    proxy_username: str = ""
    proxy_password: str = ""


@dataclass
class LocationConfig:
    zipcode: str
    store_id: str
    store_name: str
    store_location: str
    fulfillment_mode: str = "pickup"
    enabled: bool = True


@dataclass
class CategoryConfig:
    retailer: str
    category: str
    url: str
    scope: str
    notes: str = ""
    excluded_subcategories: List[str] = field(default_factory=list)


def load_settings() -> RuntimeSettings:
    load_dotenv(BASE_DIR / ".env")
    return RuntimeSettings(
        headless=os.getenv("HEADLESS", "true").strip().lower() == "true",
        min_delay_sec=float(os.getenv("MIN_DELAY_SEC", "1.8")),
        max_delay_sec=float(os.getenv("MAX_DELAY_SEC", "4.2")),
        max_retries=int(os.getenv("MAX_RETRIES", "3")),
        request_timeout_ms=int(os.getenv("REQUEST_TIMEOUT_MS", "45000")),
        target_min_records=int(os.getenv("TARGET_MIN_RECORDS", "500")),
        max_consecutive_empty_pages=int(os.getenv("MAX_CONSECUTIVE_EMPTY_PAGES", "2")),
        log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
        proxy_server=os.getenv("PROXY_SERVER", "").strip(),
        proxy_username=os.getenv("PROXY_USERNAME", "").strip(),
        proxy_password=os.getenv("PROXY_PASSWORD", "").strip(),
    )


def load_locations(path: Optional[Path] = None) -> List[LocationConfig]:
    cfg_path = path or (BASE_DIR / "config" / "locations.json")
    with cfg_path.open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return [LocationConfig(**item) for item in raw.get("locations", [])]


def _parse_exclusions(notes: str) -> List[str]:
    if not notes:
        return []
    # Matches single-quoted subcategory names in Notes like:
    # Exclude 'Shop All Foods' and 'Recipes' subcategories
    quoted = re.findall(r"'([^']+)'", notes)
    return [q.strip().lower() for q in quoted if q.strip()]


def load_categories(path: Optional[Path] = None) -> List[CategoryConfig]:
    csv_path = path or (BASE_DIR / "config" / "Walmart_Category_URLs.csv")
    categories: List[CategoryConfig] = []
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            retailer = (row.get("Retailer") or "").strip()
            if retailer and retailer.lower() != "walmart":
                continue
            notes = (row.get("Notes") or "").strip()
            categories.append(
                CategoryConfig(
                    retailer=retailer or "Walmart",
                    category=(row.get("Category (Auto)") or "").strip(),
                    url=(row.get("URL") or "").strip(),
                    scope=(row.get("Scope") or "").strip(),
                    notes=notes,
                    excluded_subcategories=_parse_exclusions(notes),
                )
            )
    return categories
