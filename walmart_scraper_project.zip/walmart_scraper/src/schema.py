import re
from collections import OrderedDict
from dataclasses import dataclass
from datetime import date
from typing import Any, Dict, Optional

REQUIRED_FIELD_ORDER = [
    "zipcode",
    "store_name",
    "store_location",
    "store_logo",
    "store_brand",
    "category",
    "sub_category",
    "product_title",
    "weight",
    "regular_price",
    "sale_price",
    "volume_deals_description",
    "volume_deals_price",
    "digital_deals_description",
    "digital_deals_price",
    "image_url",
    "url",
    "upc",
    "gupc",
    "ppm",
    "unit_price",
    "crawl_date",
]

WALMART_PRIVATE_LABELS = {
    "great value",
    "equate",
    "marketside",
    "sam's choice",
    "sams choice",
    "parent's choice",
    "parents choice",
    "mainstays",
    "pen+gear",
    "pen + gear",
    "better homes & gardens",
    "ol' roy",
    "special kitty",
    "ozark trail",
    "athletic works",
    "george",
    "time and tru",
    "no boundaries",
    "wonder nation",
    "freshness guaranteed",
    "clear american",
    "onn",
    "hyper tough",
    "hart",
    "member's mark",
}

APPROX_WEIGHT_RE = re.compile(
    r"\b(?:approx\.?|approximately|about|est\.?|estimated)\b",
    re.IGNORECASE,
)


def format_price(value: Any) -> str:
    """Format numeric prices consistently (e.g. '4.99') or return ''."""
    if value is None or value == "":
        return ""
    if isinstance(value, (int, float)):
        if value <= 0:
            return ""
        return f"{float(value):.2f}"
    text = str(value).strip().replace(",", "")
    match = re.search(r"(\d+(?:\.\d{1,2})?)", text)
    if not match:
        return ""
    num = float(match.group(1))
    return f"{num:.2f}" if num > 0 else ""


def detect_store_brand(brand: str, title: str) -> str:
    """Identify Walmart private-label products; otherwise default to 'no'."""
    combined = f"{brand} {title}".lower()
    for label in WALMART_PRIVATE_LABELS:
        if label in combined:
            return brand.strip() if brand and label in brand.lower() else label.title()
    return "no"


def has_approximate_weight(weight: str) -> bool:
    """Return True if weight contains approximate-weight wording."""
    if not weight:
        return False
    return bool(APPROX_WEIGHT_RE.search(weight))


def _clean_str(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


@dataclass
class ProductRecord:
    zipcode: str = ""
    store_name: str = ""
    store_location: str = ""
    store_logo: str = ""
    store_brand: str = "no"
    category: str = ""
    sub_category: str = ""
    product_title: str = ""
    weight: str = ""
    regular_price: str = ""
    sale_price: str = ""
    volume_deals_description: str = ""
    volume_deals_price: str = ""
    digital_deals_description: str = ""
    digital_deals_price: str = ""
    image_url: str = ""
    url: str = ""
    upc: str = ""
    gupc: str = ""
    ppm: str = ""
    unit_price: str = ""
    crawl_date: str = ""

    def __post_init__(self) -> None:
        for field_name in REQUIRED_FIELD_ORDER:
            setattr(self, field_name, _clean_str(getattr(self, field_name)))
        if not self.store_brand:
            self.store_brand = "no"
        # Pipeline rules: gupc and unit_price must always be empty string at scraper stage
        self.gupc = ""
        self.unit_price = ""
        self.regular_price = format_price(self.regular_price)
        self.sale_price = format_price(self.sale_price)
        self.volume_deals_price = format_price(self.volume_deals_price)
        self.digital_deals_price = format_price(self.digital_deals_price)
        if not self.crawl_date:
            self.crawl_date = date.today().isoformat()

    def to_ordered_dict(self) -> Dict[str, str]:
        ordered = OrderedDict()
        for key in REQUIRED_FIELD_ORDER:
            ordered[key] = getattr(self, key) or ""
        return dict(ordered)


def build_validated_record(raw: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """Validate, enforce rules, and return ordered dict or None if excluded."""
    weight = _clean_str(raw.get("weight"))
    if has_approximate_weight(weight):
        return None

    filtered = {k: raw.get(k, "") for k in REQUIRED_FIELD_ORDER}
    record = ProductRecord(**filtered)
    if not record.product_title or not record.url:
        return None
    if not record.regular_price and not record.sale_price:
        return None
    return record.to_ordered_dict()
