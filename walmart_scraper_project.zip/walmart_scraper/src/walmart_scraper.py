import asyncio
import json
import logging
import random
from datetime import date
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse, parse_qs, urlencode, urlunparse

from playwright.async_api import Browser, BrowserContext, Page, async_playwright

from src.checkpoint import CheckpointManager
from src.config_loader import CategoryConfig, LocationConfig, RuntimeSettings
from src.deal_parser import extract_weight, parse_deals, parse_ppm
from src.schema import build_validated_record, detect_store_brand, has_approximate_weight

logger = logging.getLogger("walmart_scraper")

BLOCK_MARKERS = (
    "robot or human",
    "verify your identity",
    "px-captcha",
    "access denied",
    "blocked",
)


class SilentBlockError(RuntimeError):
    """Raised when Walmart returns a bot challenge or silent block."""


class StoreContextError(RuntimeError):
    """Raised when store or fulfillment context cannot be locked or drifts."""


class WalmartScraper:
    def __init__(
        self,
        settings: RuntimeSettings,
        location: LocationConfig,
        checkpoint: CheckpointManager,
        max_records: Optional[int] = None,
    ) -> None:
        self.settings = settings
        self.location = location
        self.checkpoint = checkpoint
        self.max_records = max_records
        self.store_logo_url = "https://i5.walmartimages.com/dfw/63deb9f5-e0d7/k2-_0520f24d-25a1-432b-84eb-3a2811675803.v1.png"

    async def _jitter_sleep(self) -> None:
        delay = random.uniform(self.settings.min_delay_sec, self.settings.max_delay_sec)
        await asyncio.sleep(delay)

    async def _new_context(self, browser: Browser) -> BrowserContext:
        proxy_cfg = None
        if self.settings.proxy_server:
            proxy_cfg = {"server": self.settings.proxy_server}
            if self.settings.proxy_username:
                proxy_cfg["username"] = self.settings.proxy_username
                proxy_cfg["password"] = self.settings.proxy_password

        context = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            locale="en-US",
            timezone_id="America/Chicago",
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/129.0.0.0 Safari/537.36"
            ),
            proxy=proxy_cfg,
        )
        await context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        )
        return context

    async def _goto_with_retry(self, page: Page, url: str) -> None:
        last_exc: Optional[Exception] = None
        for attempt in range(1, self.settings.max_retries + 1):
            try:
                resp = await page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=self.settings.request_timeout_ms,
                )
                status = resp.status if resp else 0
                if status in (403, 429, 503):
                    raise SilentBlockError(f"HTTP {status} on {url}")
                await page.wait_for_timeout(1500)
                await self._check_for_blocks(page)
                return
            except Exception as exc:
                last_exc = exc
                backoff = (2 ** attempt) + random.uniform(0.5, 1.5)
                logger.warning(
                    "Attempt %d/%d failed for %s (%s). Retrying in %.1fs",
                    attempt,
                    self.settings.max_retries,
                    url,
                    exc,
                    backoff,
                )
                self.checkpoint.errors.append(f"{url} attempt {attempt}: {exc}")
                await asyncio.sleep(backoff)
        raise RuntimeError(f"Exhausted retries for {url}: {last_exc}")

    async def _check_for_blocks(self, page: Page) -> None:
        title = (await page.title()).lower()
        body_snippet = (await page.evaluate("() => document.body ? document.body.innerText.slice(0, 800) : ''")).lower()
        for marker in BLOCK_MARKERS:
            if marker in title or marker in body_snippet:
                raise SilentBlockError(f"Bot challenge detected ('{marker}') at {page.url}")

    async def ensure_store_and_fulfillment(self, page: Page) -> None:
        """Select configured ZIP/store and lock Pickup / In-store fulfillment."""
        logger.info(
            "Locking store context: ZIP=%s, store_id=%s, mode=%s",
            self.location.zipcode,
            self.location.store_id,
            self.location.fulfillment_mode,
        )
        await self._goto_with_retry(page, "https://www.walmart.com/")

        try:
            # Open Walmart fulfillment/location selector
            intent_btn = page.locator('[data-automation-id="fulfillment-intent-button"], button:has-text("How do you want your items?")').first
            if await intent_btn.count() > 0:
                await intent_btn.click(timeout=8000)
                await page.wait_for_timeout(1000)

            # Select Pickup tab if available
            pickup_tab = page.locator('button:has-text("Pickup"), [data-automation-id="pickup-intent"]').first
            if await pickup_tab.count() > 0:
                await pickup_tab.click(timeout=5000)
                await page.wait_for_timeout(800)

            # Enter ZIP code if store selector input appears
            zip_input = page.locator('input[aria-label*="Zip"], input[placeholder*="ZIP"], input[data-automation-id*="zip"]').first
            if await zip_input.count() > 0:
                await zip_input.fill(self.location.zipcode)
                await zip_input.press("Enter")
                await page.wait_for_timeout(1500)

                save_btn = page.locator('button:has-text("Save"), button:has-text("Continue")').first
                if await save_btn.count() > 0:
                    await save_btn.click(timeout=5000)
                    await page.wait_for_timeout(1500)
        except Exception as exc:
            logger.warning("UI store selector interaction note: %s", exc)

        verified = await self.verify_store_context(page)
        if not verified:
            raise StoreContextError(
                f"Failed to verify store/ZIP {self.location.zipcode} on Walmart."
            )

    async def verify_store_context(self, page: Page) -> bool:
        """Verify active header/state matches configured ZIP/store and local fulfillment."""
        header_text = await page.evaluate(
            """() => {
                const el = document.querySelector('[data-automation-id="fulfillment-intent-button"], header');
                return el ? el.innerText : '';
            }"""
        )
        normalized = " ".join(header_text.split()).lower()
        zip_ok = self.location.zipcode in normalized
        fulfillment_ok = any(
            k in normalized for k in ("pickup", "in-store", "supercenter", "store")
        )
        # Fallback check inside __NEXT_DATA__ store context if header is collapsed
        if not zip_ok:
            next_data = await self._extract_next_data(page)
            raw_str = json.dumps(next_data or {})
            zip_ok = self.location.zipcode in raw_str or self.location.store_id in raw_str

        verified = bool(zip_ok or fulfillment_ok)
        self.checkpoint.store_verifications.append(
            {
                "url": page.url,
                "expected_zipcode": self.location.zipcode,
                "expected_mode": self.location.fulfillment_mode,
                "header_excerpt": normalized[:160],
                "verified": verified,
            }
        )
        return verified

    async def _extract_next_data(self, page: Page) -> Optional[Dict[str, Any]]:
        raw = await page.evaluate(
            """() => {
                const el = document.getElementById('__NEXT_DATA__');
                return el ? el.textContent : null;
            }"""
        )
        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None

    async def _scroll_for_lazy_items(self, page: Page) -> None:
        for fraction in (0.35, 0.7, 1.0):
            await page.evaluate(
                f"window.scrollTo(0, Math.floor(document.body.scrollHeight * {fraction}));"
            )
            await page.wait_for_timeout(700)

    def _discover_subcategories_from_next_data(
        self, next_data: Dict[str, Any], cat: CategoryConfig
    ) -> List[Tuple[str, str]]:
        """Extract subcategory (name, url) pairs from Walmart category JSON."""
        found: List[Tuple[str, str]] = []
        seen_urls = set()

        def walk(node: Any) -> None:
            if isinstance(node, dict):
                title = (node.get("title") or node.get("name") or "").strip()
                link = node.get("url") or node.get("link") or ""
                if isinstance(link, dict):
                    link = link.get("clickThrough", {}).get("value", "")
                if (
                    title
                    and isinstance(link, str)
                    and ("/browse/" in link or "/cp/" in link)
                ):
                    if title.lower() not in cat.excluded_subcategories:
                        abs_url = urljoin("https://www.walmart.com", link)
                        if abs_url not in seen_urls:
                            seen_urls.add(abs_url)
                            found.append((title, abs_url))
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for item in node:
                    walk(item)

        walk(next_data)
        return found

    def _extract_items_from_next_data(
        self, next_data: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Locate product item stacks inside Walmart's __NEXT_DATA__."""
        items: List[Dict[str, Any]] = []

        def walk(node: Any) -> None:
            if isinstance(node, dict):
                if "usItemId" in node and ("name" in node or "title" in node):
                    items.append(node)
                    return
                for v in node.values():
                    walk(v)
            elif isinstance(node, list):
                for entry in node:
                    walk(entry)

        walk(next_data)
        return items

    def _is_local_walmart_offer(self, item: Dict[str, Any]) -> bool:
        """
        Reject 3P marketplace offers and shipping-only offers.
        Only allow Walmart-sold items with Pickup or In-store availability.
        """
        if item.get("isMarketplace") is True:
            return False
        seller = str(item.get("sellerName") or "").strip().lower()
        if seller and "walmart" not in seller:
            return False

        fulfillment_str = json.dumps(
            item.get("fulfillmentBadgeGroups")
            or item.get("fulfillmentBadges")
            or item.get("fulfillmentType")
            or ""
        ).lower()

        if "pickup" in fulfillment_str or "in_store" in fulfillment_str or "in-store" in fulfillment_str:
            return True
        if "shipping" in fulfillment_str and "pickup" not in fulfillment_str:
            return False
        # If fulfillment metadata is omitted at card level, rely on locked store context
        return True

    def _normalize_item(
        self, item: Dict[str, Any], category_name: str, sub_category_name: str
    ) -> Optional[Dict[str, str]]:
        if not self._is_local_walmart_offer(item):
            self.checkpoint.excluded_marketplace_or_shipping += 1
            return None

        title = str(item.get("name") or item.get("title") or "").strip()
        canonical = str(item.get("canonicalUrl") or "").strip()
        product_url = urljoin("https://www.walmart.com", canonical) if canonical else ""
        item_id = str(item.get("usItemId") or "").strip()
        dedup_key = item_id or product_url
        if not dedup_key:
            return None
        if dedup_key in self.checkpoint.seen_keys:
            self.checkpoint.duplicates_skipped += 1
            return None

        price_info = item.get("priceInfo") or {}
        current_price = (
            price_info.get("currentPrice", {}).get("price")
            if isinstance(price_info.get("currentPrice"), dict)
            else price_info.get("linePrice")
        )
        was_price = (
            price_info.get("wasPrice", {}).get("price")
            if isinstance(price_info.get("wasPrice"), dict)
            else None
        )

        regular_price = was_price if was_price else current_price
        sale_price = current_price if was_price and current_price != was_price else ""

        promo_texts: List[str] = []
        for badge_key in ("badges", "promoBadges", "dealBadges"):
            badges = item.get(badge_key)
            if isinstance(badges, list):
                for b in badges:
                    if isinstance(b, dict) and b.get("text"):
                        promo_texts.append(str(b["text"]))
                    elif isinstance(b, str):
                        promo_texts.append(b)
        if price_info.get("unitPrice"):
            pass

        deals = parse_deals(promo_texts)
        raw_ppm = (
            price_info.get("pricePerUnit", {}).get("priceString")
            if isinstance(price_info.get("pricePerUnit"), dict)
            else str(price_info.get("unitPrice") or "")
        )
        ppm = parse_ppm(str(raw_ppm or ""))
        weight = extract_weight(str(item.get("weight") or ""), title)
        if has_approximate_weight(weight):
            self.checkpoint.excluded_approx_weight += 1
            return None

        image_info = item.get("imageInfo") or {}
        image_url = str(
            image_info.get("thumbnailUrl")
            or item.get("image")
            or item.get("imageUrl")
            or ""
        ).strip()

        brand = str(item.get("brand") or "").strip()
        store_brand = detect_store_brand(brand, title)

        raw_record = {
            "zipcode": self.location.zipcode,
            "store_name": self.location.store_name,
            "store_location": self.location.store_location,
            "store_logo": self.store_logo_url,
            "store_brand": store_brand,
            "category": category_name,
            "sub_category": sub_category_name,
            "product_title": title,
            "weight": weight,
            "regular_price": regular_price,
            "sale_price": sale_price,
            "volume_deals_description": deals["volume_deals_description"],
            "volume_deals_price": deals["volume_deals_price"],
            "digital_deals_description": deals["digital_deals_description"],
            "digital_deals_price": deals["digital_deals_price"],
            "image_url": image_url,
            "url": product_url,
            "upc": str(item.get("upc") or "").strip(),
            "gupc": "",
            "ppm": ppm,
            "unit_price": "",
            "crawl_date": date.today().isoformat(),
        }

        validated = build_validated_record(raw_record)
        if validated is None:
            return None
        self.checkpoint.seen_keys.add(dedup_key)
        return validated

    @staticmethod
    def _with_page_param(url: str, page_num: int) -> str:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        qs["page"] = [str(page_num)]
        new_query = urlencode(qs, doseq=True)
        return urlunparse(parsed._replace(query=new_query))

    async def _scrape_listing_pages(
        self, page: Page, category_name: str, sub_category_name: str, base_url: str, start_page: int = 1
    ) -> int:
        added_total = 0
        consecutive_empty = 0
        page_num = start_page

        while True:
            if self.max_records and len(self.checkpoint.staged_records) >= self.max_records:
                return added_total

            self.checkpoint.current_category = category_name
            self.checkpoint.current_subcategory = sub_category_name
            self.checkpoint.current_page = page_num

            target_url = self._with_page_param(base_url, page_num)
            await self._goto_with_retry(page, target_url)
            await self._scroll_for_lazy_items(page)

            if page_num % 3 == 1:
                if not await self.verify_store_context(page):
                    raise StoreContextError(
                        f"Store context drifted while scraping {target_url}"
                    )

            next_data = await self._extract_next_data(page)
            raw_items = self._extract_items_from_next_data(next_data) if next_data else []

            page_added = 0
            for raw_item in raw_items:
                rec = self._normalize_item(raw_item, category_name, sub_category_name)
                if rec:
                    self.checkpoint.staged_records.append(rec)
                    page_added += 1
                    added_total += 1
                    if self.max_records and len(self.checkpoint.staged_records) >= self.max_records:
                        break

            self.checkpoint.save()
            logger.info(
                "[%s > %s] Page %d: +%d valid (Total staged: %d)",
                category_name,
                sub_category_name or "Root",
                page_num,
                page_added,
                len(self.checkpoint.staged_records),
            )

            if page_added == 0:
                consecutive_empty += 1
                if consecutive_empty >= self.settings.max_consecutive_empty_pages:
                    break
            else:
                consecutive_empty = 0

            page_num += 1
            await self._jitter_sleep()

        return added_total

    async def run(self, categories: List[CategoryConfig], resume: bool = False) -> None:
        if resume and self.checkpoint.load():
            logger.info(
                "Resuming from checkpoint: %d records staged, completed=%s",
                len(self.checkpoint.staged_records),
                self.checkpoint.completed_categories,
            )

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.settings.headless)
            context = await self._new_context(browser)
            page = await context.new_page()

            try:
                await self.ensure_store_and_fulfillment(page)

                for cat in categories:
                    if cat.category in self.checkpoint.completed_categories:
                        logger.info("Skipping already completed category: %s", cat.category)
                        continue
                    if self.max_records and len(self.checkpoint.staged_records) >= self.max_records:
                        break

                    logger.info("Starting category: %s (%s)", cat.category, cat.url)
                    await self._goto_with_retry(page, cat.url)
                    next_data = await self._extract_next_data(page)
                    subcats = (
                        self._discover_subcategories_from_next_data(next_data, cat)
                        if next_data
                        else []
                    )

                    cat_count = self.checkpoint.category_counts.get(cat.category, 0)
                    if subcats:
                        logger.info("Discovered %d subcategories in %s", len(subcats), cat.category)
                        for sub_name, sub_url in subcats:
                            if self.max_records and len(self.checkpoint.staged_records) >= self.max_records:
                                break
                            start_pg = (
                                self.checkpoint.current_page
                                if (
                                    resume
                                    and self.checkpoint.current_category == cat.category
                                    and self.checkpoint.current_subcategory == sub_name
                                )
                                else 1
                            )
                            added = await self._scrape_listing_pages(
                                page, cat.category, sub_name, sub_url, start_page=start_pg
                            )
                            cat_count += added
                    else:
                        start_pg = (
                            self.checkpoint.current_page
                            if resume and self.checkpoint.current_category == cat.category
                            else 1
                        )
                        cat_count += await self._scrape_listing_pages(
                            page, cat.category, "", cat.url, start_page=start_pg
                        )

                    self.checkpoint.category_counts[cat.category] = cat_count
                    self.checkpoint.completed_categories.append(cat.category)
                    self.checkpoint.current_page = 1
                    self.checkpoint.save()
            finally:
                await context.close()
                await browser.close()
