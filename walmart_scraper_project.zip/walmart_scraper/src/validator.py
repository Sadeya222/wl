import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

from src.checkpoint import CheckpointManager
from src.schema import REQUIRED_FIELD_ORDER


class RunValidator:
    """
    Validates schema, store/fulfillment lock, completeness, and thin-yield anomalies
    before atomically promoting staging output to final output.
    """

    def __init__(self, base_dir: Path, zipcode: str, target_min_records: int) -> None:
        self.base_dir = base_dir
        self.zipcode = zipcode
        self.target_min_records = target_min_records
        self.staging_dir = base_dir / "output" / "staging"
        self.final_dir = base_dir / "output" / "final"
        self.reports_dir = base_dir / "output" / "reports"
        for d in (self.staging_dir, self.final_dir, self.reports_dir):
            d.mkdir(parents=True, exist_ok=True)

    def validate_and_publish(
        self,
        checkpoint: CheckpointManager,
        runtime_seconds: float,
    ) -> Tuple[bool, Dict[str, Any]]:
        records = checkpoint.staged_records
        issues: List[str] = []
        warnings: List[str] = []

        # 1. Store & fulfillment verification check
        failed_verifications = [
            v for v in checkpoint.store_verifications if not v.get("verified", False)
        ]
        if not checkpoint.store_verifications:
            issues.append("No store/fulfillment verification events were recorded.")
        elif failed_verifications:
            issues.append(
                f"Store/fulfillment verification failed {len(failed_verifications)} time(s)."
            )

        # 2. Minimum record threshold
        if len(records) == 0:
            issues.append("Run produced 0 valid records.")
        elif len(records) < self.target_min_records:
            issues.append(
                f"Record count {len(records)} is below required minimum {self.target_min_records}."
            )

        # 3. Schema, null, duplicate, and forbidden-field checks
        seen_urls = set()
        duplicate_urls = 0
        for idx, rec in enumerate(records):
            keys = list(rec.keys())
            if keys != REQUIRED_FIELD_ORDER:
                issues.append(f"Record {idx} field order mismatch.")
                break
            if any(v is None for v in rec.values()):
                issues.append(f"Record {idx} contains null value(s).")
                break
            if rec.get("gupc") != "" or rec.get("unit_price") != "":
                issues.append(f"Record {idx} populated forbidden gupc/unit_price.")
                break
            url = rec.get("url", "")
            if url in seen_urls:
                duplicate_urls += 1
            seen_urls.add(url)

        if duplicate_urls > 0:
            issues.append(f"Found {duplicate_urls} duplicate URLs in staged output.")

        # 4. Category completeness & thin-yield comparison
        for cat, count in checkpoint.category_counts.items():
            if count == 0:
                warnings.append(f"Category '{cat}' returned 0 products.")
            prior = checkpoint.prior_category_counts.get(cat)
            if prior and prior >= 20 and count < int(prior * 0.4):
                warnings.append(
                    f"Thin yield in '{cat}': {count} vs prior {prior} (<40%)."
                )

        passed = len(issues) == 0

        # Always write staging file
        staging_file = self.staging_dir / f"{self.zipcode}_products.json"
        self._atomic_write_json(staging_file, records)

        # Only promote to final output if validation PASSED
        final_file = self.final_dir / f"{self.zipcode}_products.json"
        if passed:
            self._atomic_write_json(final_file, records)
            checkpoint.save_prior_counts()
            checkpoint.clear()

        report = self._build_report(
            checkpoint=checkpoint,
            records=records,
            runtime_seconds=runtime_seconds,
            passed=passed,
            issues=issues,
            warnings=warnings,
            final_file=str(final_file) if passed else "NOT_PROMOTED_PRESERVED_PRIOR",
        )
        report_file = self.reports_dir / f"{self.zipcode}_run_report.json"
        self._atomic_write_json(report_file, report)
        return passed, report

    def _build_report(
        self,
        checkpoint: CheckpointManager,
        records: List[Dict[str, str]],
        runtime_seconds: float,
        passed: bool,
        issues: List[str],
        warnings: List[str],
        final_file: str,
    ) -> Dict[str, Any]:
        total = len(records)
        completeness = {}
        for field in REQUIRED_FIELD_ORDER:
            non_empty = sum(1 for r in records if r.get(field, "") != "")
            completeness[field] = {
                "populated": non_empty,
                "pct": round((non_empty / total) * 100, 2) if total else 0.0,
            }

        sample_ppm = next((r for r in records if r.get("ppm")), None)
        sample_volume = next(
            (r for r in records if r.get("volume_deals_description")), None
        )
        sample_digital = next(
            (r for r in records if r.get("digital_deals_description")), None
        )
        sample_no_deal = next(
            (
                r
                for r in records
                if not r.get("volume_deals_description")
                and not r.get("digital_deals_description")
            ),
            None,
        )

        return {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "zipcode": self.zipcode,
            "validation_passed": passed,
            "final_output_path": final_file,
            "runtime_seconds": round(runtime_seconds, 2),
            "total_unique_records": total,
            "count_by_category": checkpoint.category_counts,
            "duplicates_prevented": checkpoint.duplicates_skipped,
            "excluded_approx_weight": checkpoint.excluded_approx_weight,
            "excluded_marketplace_or_shipping": checkpoint.excluded_marketplace_or_shipping,
            "field_completeness": completeness,
            "store_fulfillment_verifications": checkpoint.store_verifications[:10],
            "samples": {
                "ppm": sample_ppm,
                "volume_deal": sample_volume,
                "digital_deal": sample_digital,
                "no_deal": sample_no_deal,
            },
            "issues": issues,
            "warnings": warnings,
            "errors": checkpoint.errors,
        }

    @staticmethod
    def _atomic_write_json(target: Path, payload: Any) -> None:
        fd, tmp_name = tempfile.mkstemp(dir=str(target.parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as tmp_f:
                json.dump(payload, tmp_f, indent=2, ensure_ascii=False)
            os.replace(tmp_name, target)
        except Exception:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
            raise
