import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Set


class CheckpointManager:
    """
    Persists genuine run state (completed categories, current page, seen keys,
    and staged records) using atomic file writes so interruptions never corrupt state.
    """

    def __init__(self, base_dir: Path, zipcode: str) -> None:
        self.base_dir = base_dir
        self.zipcode = zipcode
        self.checkpoint_dir = base_dir / "output" / "checkpoints"
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_path = self.checkpoint_dir / f"{zipcode}_checkpoint.json"
        self.prior_counts_path = self.checkpoint_dir / f"{zipcode}_prior_counts.json"

        self.completed_categories: List[str] = []
        self.current_category: str = ""
        self.current_subcategory: str = ""
        self.current_page: int = 1
        self.seen_keys: Set[str] = set()
        self.staged_records: List[Dict[str, str]] = []
        self.category_counts: Dict[str, int] = {}
        self.duplicates_skipped: int = 0
        self.excluded_approx_weight: int = 0
        self.excluded_marketplace_or_shipping: int = 0
        self.store_verifications: List[Dict[str, Any]] = []
        self.errors: List[str] = []
        self.prior_category_counts: Dict[str, int] = self._load_prior_counts()

    def _load_prior_counts(self) -> Dict[str, int]:
        if not self.prior_counts_path.exists():
            return {}
        try:
            with self.prior_counts_path.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_prior_counts(self) -> None:
        self._atomic_write(self.prior_counts_path, self.category_counts)

    def load(self) -> bool:
        if not self.checkpoint_path.exists():
            return False
        with self.checkpoint_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        self.completed_categories = data.get("completed_categories", [])
        self.current_category = data.get("current_category", "")
        self.current_subcategory = data.get("current_subcategory", "")
        self.current_page = int(data.get("current_page", 1))
        self.seen_keys = set(data.get("seen_keys", []))
        self.staged_records = data.get("staged_records", [])
        self.category_counts = data.get("category_counts", {})
        self.duplicates_skipped = int(data.get("duplicates_skipped", 0))
        self.excluded_approx_weight = int(data.get("excluded_approx_weight", 0))
        self.excluded_marketplace_or_shipping = int(
            data.get("excluded_marketplace_or_shipping", 0)
        )
        self.store_verifications = data.get("store_verifications", [])
        self.errors = data.get("errors", [])
        return True

    def save(self) -> None:
        payload = {
            "zipcode": self.zipcode,
            "completed_categories": self.completed_categories,
            "current_category": self.current_category,
            "current_subcategory": self.current_subcategory,
            "current_page": self.current_page,
            "seen_keys": sorted(self.seen_keys),
            "staged_records": self.staged_records,
            "category_counts": self.category_counts,
            "duplicates_skipped": self.duplicates_skipped,
            "excluded_approx_weight": self.excluded_approx_weight,
            "excluded_marketplace_or_shipping": self.excluded_marketplace_or_shipping,
            "store_verifications": self.store_verifications,
            "errors": self.errors,
        }
        self._atomic_write(self.checkpoint_path, payload)

    def clear(self) -> None:
        if self.checkpoint_path.exists():
            self.checkpoint_path.unlink()

    @staticmethod
    def _atomic_write(target: Path, payload: Any) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(dir=str(target.parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as tmp_f:
                json.dump(payload, tmp_f, indent=2, ensure_ascii=False)
            os.replace(tmp_name, target)
        except Exception:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
            raise
