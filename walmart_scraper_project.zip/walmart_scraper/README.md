# Production Walmart Scraper (Local VS Code & Azure-Ready)

A Playwright-based Walmart scraper built for local VS Code execution and seamless deployment to Microsoft Azure.

## Project Structure

- `config/locations.json` — Store ZIP codes, store IDs, and fulfillment modes (`pickup` / `in-store`).
- `config/Walmart_Category_URLs.csv` — Category URLs and subcategory exclusion rules.
- `.env.example` — Proxy, pacing, and validation thresholds (keep `.env` out of git).
- `src/config_loader.py` — External configuration and CSV exclusion parser.
- `src/schema.py` — Strict 22-field JSON schema, price formatting, private-label detection, and approximate-weight exclusion.
- `src/deal_parser.py` — Separates volume deals, digital deals, and verbatim PPM without calculating missing prices.
- `src/checkpoint.py` — Atomic checkpointing per category/page/seen-item for safe interruption & resume.
- `src/validator.py` — Schema, location-lock, and thin-yield validation + atomic promotion to `output/final/`.
- `src/walmart_scraper.py` — Async Playwright scraper with store locking, marketplace/shipping filtering, and silent-block detection.
- `src/main.py` — CLI entry point.

## Local Setup (VS Code)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

pip install -r requirements.txt
playwright install chromium
cp .env.example .env
```

## Run a Live Demo (>=500 Records)

```bash
python -m src.main --zipcode 75201 --max-records 600
```

Resume an interrupted run:

```bash
python -m src.main --zipcode 75201 --resume
```

Outputs:
- `output/final/<zipcode>_products.json` — Promoted only if all validation checks pass.
- `output/reports/<zipcode>_run_report.json` — Contest metrics (counts, completeness %, deal/PPM samples, store verification proof).
- `output/logs/` — Full structured execution logs.

## Adding Locations or Categories

- **Locations:** Add an entry to `config/locations.json` and run with `--zipcode <zip>`.
- **Categories:** Edit `config/Walmart_Category_URLs.csv` (exclusions in `Notes` like `Exclude 'Recipes'` are parsed automatically).

## Azure Deployment Notes

Package the project into a Docker container with `mcr.microsoft.com/playwright/python` and schedule twice weekly (e.g., Monday & Thursday at 06:00 UTC) using an Azure Container Apps Job (`0 6 * * 1,4`) with secrets stored in Azure Key Vault.
